Docker file Executes main.go file

with default port 8080

In main.go file I have added counter for counting number of requests.

Also have imported module of prometheus from git hub.


